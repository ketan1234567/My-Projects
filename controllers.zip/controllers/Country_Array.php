<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Country_Array extends CI_Controller
{
    public function country()
    {

        $this->load->view("cuntry_array/index");
    }

    public function select_c_name()
    {

        $country = $this->input->post('country');
        $in = array('RJ', 'SB', 'PK', 'AD');
        $in = array("Peter", "Joe", "Glenn", "Cleveland");

        if (in_array($country, $in)) {
            echo "Match found";
        } else {
            echo "Match not found";
        }

        // $name = array('rushikesh' => 'RJ',  'Ashruba' => 'AP', 'Sujit' => 'SB', 'Prathamesh' => 'PK', 'Akshay' => 'AD');
        // foreach ($in as $key => $value) {

        //     if ($value ==  $country) {
        //         echo 'selected name is ' . $value;
        //         echo " <br>";
        //     }  else {
        //         echo 'array is empty';
        //         echo " <br>";
        //     }
        // }

        die();
    }
}
