<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Crud_Controller extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Crud_Model');
    $this->load->database();
    $this->load->library('session');

    if (!$this->session->userdata('email')) {
      $this->session->set_flashdata('error', 'Invalid Username and Password');
      redirect('login');
    }
  }

  public function index()
  {
    $this->load->view('index');
  }
  public function insert_record()
  {

    $file = $_FILES['image']['name'];


    $all_file = array();
    for ($i = 0; $i < count($file); $i++) {
      $f_name = $_FILES['image']['name'][$i];
      $f_type = $_FILES['image']['type'][$i];
      $f_tmp_name = $_FILES['image']['tmp_name'][$i];
      $f_size = $_FILES['image']['size'][$i];
      if ($f_size < 1e+7) {
        move_uploaded_file($f_tmp_name, "uploads/" . $f_name);
        array_push($all_file, 'uploads/' . $f_name);
      }
    }


    $images = json_encode($all_file);

    $data = array(
      'f_name' =>   $f_name = $this->input->post('f_name'),
      'l_name' =>  $l_name = $this->input->post('l_name'),
      'address' =>  $address = $this->input->post('address'),
      'gender' =>  $gender = $this->input->post('gender'),
      'contact' =>  $contact = $this->input->post('contact'),
      'email' =>  $email = $this->input->post('email'),
      'age' =>  $age = $this->input->post('age'),
      'image' => $images,
      'status' => 1
    );


    $result = $this->Crud_Model->Insert_data($data);
    redirect('show_record');
  }
  public function show_record()
  {

    $result['data'] = $this->Crud_Model->show_record();

    $this->load->view('show_record', $result);
  }
  public function delete_record($id)
  {

    $result['data'] = $this->Crud_Model->delete_record($id);

    redirect('show_record');
  }
  public function update_record($id)
  {
    $result['data'] = $this->Crud_Model->update_record($id);


    $this->load->view('update_record', $result);
  }

  public function update_data()
  {
    $file = $_FILES['image']['name'];


    $all_file = array();
    for ($i = 0; $i < count($file); $i++) {
      $f_name = $_FILES['image']['name'][$i];
      $f_type = $_FILES['image']['type'][$i];
      $f_tmp_name = $_FILES['image']['tmp_name'][$i];
      $f_size = $_FILES['image']['size'][$i];
      if ($f_size < 1e+7) {
        move_uploaded_file($f_tmp_name, "uploads/" . $f_name);
        array_push($all_file, 'uploads/' . $f_name);
      }
    }

    $images = json_encode($all_file);

    $id = $this->input->post('id');

    if (!empty($_FILES['image']['name'])) {
      $data = array(
        'f_name' =>  $this->input->post('f_name'),
        'l_name' =>   $this->input->post('l_name'),
        'address' => $this->input->post('address'),
        'gender' =>   $this->input->post('gender'),
        'contact' => $this->input->post('contact'),
        'email' =>   $this->input->post('email'),
        'age' =>   $this->input->post('age'),
        'image' => $images,
        'status' => 1
      );
    } else {
      $data = array(
        'f_name' =>  $this->input->post('f_name'),
        'l_name' =>   $this->input->post('l_name'),
        'address' => $this->input->post('address'),
        'gender' =>   $this->input->post('gender'),
        'contact' => $this->input->post('contact'),
        'email' =>   $this->input->post('email'),
        'age' =>   $this->input->post('age'),
        'status' => 1
      );
    }
    $result = $this->Crud_Model->update_data($id, $data);

    redirect('show_record');
  }


  public function search()
  {
    $str = $this->input->post('str');
    $result = $this->Crud_Model->search_data($str);


    var_dump($result);

    echo json_encode($result);
  }

  public function search_data()
  {

    $str = $this->input->post('str');
    $result = $this->Crud_Model->search_data($str);
    $this->load->view('search_data', $result);
  }

  // code

  public function tabs_index()
  {

    $this->load->view('tabs_example');
  }

  public function tab_one()
  {

    $this->load->model("Members_model");
    $fetch_data = $this->Members_model->make_datatables();

    $data = array();
    foreach ($fetch_data as $row) {
      $sub_array = array();
      $sub_array[] =  '<span class="label label-' . ($row->status == 1 ? 'success' : 'danger') . '">' . ($row->status == 1 ? 'active' : 'inactive') . '</span>';
      $sub_array[] = '<img src="' . base_url() . 'uploads/' . $row->image . '" class="img-thumbnail" width="150px" height="135px" />';
      $sub_array[] = $row->f_name;
      $sub_array[] = $row->l_name;
      $sub_array[] = $row->address;
      $sub_array[] = $row->email;
      $sub_array[] = $row->gender;
      $sub_array[] = $row->contact;
      $sub_array[] = $row->age;
      $sub_array[] = '<input type="button" onclick="getbtnid(this.id);" placeholder="Update" name="update" value="status" id="' . $row->id . '" class="btn btn-success btn-xs">';
      $sub_array[] = '<button type="button" name="delete" id="' . $row->id . '" class="btn btn-danger btn-xs">Delete</button>';
      $data[] = $sub_array;
    }
    $output = array(
      "draw"                    =>     intval($_POST["draw"]),
      "recordsTotal"          =>      $this->Members_model->get_all_data(),
      "recordsFiltered"     =>     $this->Members_model->get_filtered_data(),
      "data"                    =>     $data
    );
    echo json_encode($output);
  }
}
