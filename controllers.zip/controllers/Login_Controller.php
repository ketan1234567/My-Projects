<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login_Controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Login_Model');
        $this->load->database();
    }
    public function login_page()
    {
        $data['title'] = 'CodeIgniter Simple Login Form With Sessions';
        $this->load->view("login_page/login");
        // $this->load->view('login_page/login');
    }

    public function login_user()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $result = $this->Login_Model->login_user($email, $password);
        if (!empty($result)) {
            $session_data = array(
                'email'     =>    $result['email'],
                'password'  =>    $result['password'],
                'name'      =>    $result['f_name'],
                'status'    =>    $result['status'],
            );
            $this->session->set_userdata($session_data);
            $this->load->view('index');
        } else {
            $this->session->set_flashdata('error', 'Invalid Username and Password');
            $this->load->view('login_page/login');
        }
    }
}
