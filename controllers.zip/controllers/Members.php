<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Members extends CI_Controller{
     function __construct()
     {
       parent::__construct();
       $this->load->model('Members_model');
         $this->load->library('session');
    if (!$this->session->userdata('email')) {
      $this->session->set_flashdata('error', 'Invalid Username and Password');
      redirect('login');
    }
              
     
     }
   
    //functions  
    function index(){  
  
        $data["title"] = "All Record";  
        $this->load->view('members/index', $data);  
   }  
   function fetch_user(){  
        $this->load->model("Members_model");  
        $fetch_data = $this->Members_model->make_datatables();  
     
        $data = array();  
        foreach($fetch_data as $row)  
        {  
             $sub_array = array();  
          //    $sub_array[] =  '<span class="label label-' .($row->status == 1 ? 'success' : 'danger') . '">' . ($row->status == 1 ? 'active' : 'inactive') . '</span>';
          $sub_array[] = $row->id;    
          $sub_array[] = '<img src="'.base_url().'uploads/'.$row->image.'" class="img-thumbnail" width="150px" height="135px" />';  
             $sub_array[] = $row->f_name;  
             $sub_array[] = $row->l_name;  
             $sub_array[] = $row->address;    
             $sub_array[] = $row->email;  
             $sub_array[] = $row->gender;  
             $sub_array[] = $row->contact;  
             $sub_array[] = $row->age;  
             $sub_array[] = '<input type="button" onclick="getbtnid(this.id);" placeholder="Update" name="update" value="status" id="'.$row->id.'" class="btn btn-success btn-xs">';  
             $sub_array[] = '<button type="button" name="delete" id="'.$row->id.'" class="btn btn-danger btn-xs">Delete</button>';  
             $data[] = $sub_array;  
        }  
        $output = array(  
             "draw"                    =>     intval($_POST["draw"]),  
             "recordsTotal"          =>      $this->Members_model->get_all_data(),  
             "recordsFiltered"     =>     $this->Members_model->get_filtered_data(),  
             "data"                    =>     $data  
        );  
        echo json_encode($output);  
   }  

   public function status_change(){
    $this->load->model("Members_model");  

    $id=$this->input->post('id');

    $delete_record = $this->Members_model->status_change($id);  

   }

   public function multipal_email(){

     $this->load->view('multipal_email');
   }
    
}
