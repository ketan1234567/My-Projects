<?php

require APPPATH . 'libraries/REST_Controller.php';

class Item extends REST_Controller
{
    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('api/Login_Model_api');
        // if (!$this->session->userdata('email')) {
        //     $this->session->set_flashdata('error', 'Invalid Username and Password');
        //     $this->load->view('login_page/login');
        //   }
    }
    /**
     * Get All Data from this method.
     *
     * @return Response
     */
    public function index_post()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        if (empty($email)) {
            $data = array(
                'status' => 412,
                'message' => 'Email Is Empty'
            );
            $this->response($data, REST_Controller::HTTP_PRECONDITION_FAILED);
        } elseif (empty($password)) {
            $data = array(
                'status' => 412,
                'message' => 'Password Is Empty'
            );
            $this->response($data, REST_Controller::HTTP_PRECONDITION_FAILED);
        } elseif (!empty($email) && !empty($password)) {
            $result = $this->Login_Model_api->user_login($email, $password);

        
            if ($result['status'] == 200) {
                $data = array(
                    'status' => 200,
                    'result' => 'record fatch successully',
                    'data' => $result['data']
                );
                $this->response($data, REST_Controller::HTTP_OK);
            }
            else{
                $data = array(
                    'status' => 412,
                    'result' => 'credential Failed',
                    
                );
                $this->response($data, REST_Controller::HTTP_PRECONDITION_FAILED);
            }
        }
    }
    public function record_get()
    {
        $result = $this->Login_Model_api->get_data();
        if (empty($result)) {
            $data = array(
                'status' => 412,
                'result' => 'record not fatch',
               
            );
            $this->response($data, REST_Controller::HTTP_PRECONDITION_FAILED);
        } else {
            $data = array(
                'status' => 200,
                'result' => 'record fatch successully',
                'data' => $result
            );
            $this->response($data, REST_Controller::HTTP_OK);
        }
    }
}
