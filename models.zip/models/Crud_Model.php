<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_Model extends CI_Model {

public function Insert_data($data){
  
   $query= $this->db->insert('fields',$data);
   return $query;
}
public function show_record(){

$query=$this->db->select('*')->from('fields')->get()->result_array();
return $query;

}
      public function delete_record($id){
      $this->db->where('id', $id);
      $query=$this->db->delete('fields');
      return $query;
          }
    public function update_record($id){

$query=$this->db->select('*')->where('id',$id)->get('fields')->row_array();
return $query;

    }
    public function update_data($id,$data)
{
  
 
$this->db->where('id', $id);
 $query=$this->db->update('fields', $data);
return $query;

}
public function search_data($query){

     $this->db->select('*')->from('fields');
    $this->db->like('f_name',$query);
   $data= $this->db->get()->result_array();
    return $data;
}



}

