<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_Model extends CI_Model
{

    public function login_user($email, $password)
    {

        $query = $this->db->select('email,password,f_name,status')->where('email', $email)->where('password', $password)->limit(1)->get('fields')->row_array();

        return $query;
    }
}
