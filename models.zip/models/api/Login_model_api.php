<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_model_api extends CI_Model
{

    public function __construct()
    {
        $this->load->database();
    }

    public function user_login($email, $password)
    {
        $query = $this->db->select('email,password,f_name,status')->where('email', $email)->where('password', $password)->limit(1)->get('fields')->row_array();
        if (!empty($query)) {
            $result = array(
                'status' => 200,
                'data' => $query
            );
        } else {
            $result = array(
                'status' => 201,
            );
        }
        return $result;
    }


    public function get_data()
    {
        $result = $this->db->select('*')->get('fields')->result_array();
        return $result;
    }
}
