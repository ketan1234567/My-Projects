<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.1/toastr.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.js" data-semver="3.0.0" data-require="jquery"></script>

    <!-- Including Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

    <!-- Including jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js">
    </script>

    <!-- Including Bootstrap JS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">
    </script>

    <style>
        #form_body {

            margin-top: 10%;
            border: 1px solid gray;
            border-radius: 5px;
            padding: 15px 15px 15px 15px;
            box-shadow: 0px 0px 20px 1px grey;
        }

        #submit_button {
            text-align: center;
            align-items: center;
        }
    </style>
</head>

<body>

    <body>
        <div class="container">

            <div class="col-md-3"></div>
            <div class="col-md-6 " id="form_body">
                <form action="<?php echo base_url('login'); ?>" method="post">

                    <div id="alert" onload="myFunction()" class="alert alert-danger">

                        <?php
                        if ($this->session->flashdata('error') == !NULL) {
                            echo $this->session->flashdata('error');
                        }
                        ?>


                    </div>
                    <div class="form-group">
                        <label><b> Email: </b></label>
                        <input class="form-control" name="email" id="email" type="email" placeholder="Enter your email" required>
                        <label> <b>Password: </b></label>
                        <input id="pass" class="form-control" name="password" type="password" placeholder="enter your password" required>
                    </div>
                    <div class="form-group">
                        <button class="btn  btn-primary" id="submit_button" type="submit">Login</button>

                    </div>

                </form>
            </div>
            <div class="col-md-3"></div>

        </div>

        <script type="text/javascript">
            function myFunction(){
                $("#alert").remove();
            }
            setTimeout(function() {
               // var email = $("#email").val();
                // Closing the alert
              //  alert("hiii"+email);
               // if(email!=""){
                $('#alert').alert('close');
               // }
            }, 5000);
        </script>

    </body>



</html>