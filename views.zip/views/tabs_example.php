<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tabs</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />


    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</head>
<style>
    body {
        padding: 10px;

    }

    #exTab1 .tab-content {
        color: white;
        background-color: gray;
        padding: 5px 15px;
    }

    #exTab2 h3 {
        color: white;
        background-color: gray;
        padding: 5px 15px;
    }

    /* remove border radius for the tab */

    #exTab1 .nav-pills>li>a {
        border-radius: 0;
    }

    /* change border radius for the tab , apply corners on top*/

    #exTab3 .nav-pills>li>a {
        border-radius: 4px 4px 0 0;
    }

    #exTab3 .tab-content {
        color: white;
        background-color: gray;
        padding: 5px 15px;
    }
</style>

<body>

    <div class="container">
        <h1>Bootstrap tab panel example </h1>

        <div id="exTab1">
            <ul class="nav nav-pills">
                <li class="active">
                    <a href="#active" data-toggle="tab">Active status</a>
                </li>
                <li><a href="#2a" data-toggle="tab">In Active status</a>
                </li>
                <li><a href="#3a" data-toggle="tab">Deleted record</a>
                </li>
            </ul>

            <div class="tab-content clearfix">
                <div class="tab-pane active" id="active">
                    <!-- tab one start -->
                    <div class="table-responsive">
                        <table class="table table-borderd" id="active-record" style="background-color: #607cab;">
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Address</th>
                                    <th>email</th>
                                    <th>Gender</th>
                                    <th>Contact</th>
                                    <th>Age</th>
                                    <th>delete</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                    <!-- tab one end -->
                </div>
                <div class="tab-pane" id="2a">
                    <!-- table two start -->

                    <div class="table-responsive">
                        <table class="table table-borderd"  style="background-color:#353d4a;">
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Address</th>
                                    <th>email</th>
                                    <th>Gender</th>
                                    <th>Contact</th>
                                    <th>Age</th>
                                    <th>delete</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                    <!-- table  two end -->
                </div>
                <div class="tab-pane" id="3a">
                    <!-- table three start -->

                    <div class="table-responsive">
                        <table class="table table-borderd" style="background-color:#6e5b40;">
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Address</th>
                                    <th>email</th>
                                    <th>Gender</th>
                                    <th>Contact</th>
                                    <th>Age</th>
                                    <th>delete</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                    <!-- table  three end -->
                </div>

            </div>
        </div>

    </div>


   

</body>

</html>
<script >
    $(document).ready(function() {
        var dataTable = $('#active-record').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [],

            "ajax": {
                url: "<?php echo base_url().'Crud_Controller/tab_one'; ?>",
                type: "POST"
            },
            "columnDefs": [{
                "orderable": false,
            }, ],
        });
    });
</script>